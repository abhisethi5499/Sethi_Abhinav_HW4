window._lang = "nl_NL" ;
window._l10s = window._l10s || { } ;
window._l10s["nl_NL"] = {

  "#{0} from now": "#{0} vanaf nu",
  "#{0} ago": "#{0} geleden",
  "on #{0}": "op #{0}",
  "less than a minute": "minder dan een minuut",
  "#{0} minute": "#{0} minuut",
  "#{0} minutes": "#{0} minuten",
  "about one hour": "ongeveer een uur",
  "#{0} hours": "#{0} uren",
  "one day": "een dag",
  "about one day": "ongeveer een dag",
  "#{0} days": "#{0} dagen"

} ;




