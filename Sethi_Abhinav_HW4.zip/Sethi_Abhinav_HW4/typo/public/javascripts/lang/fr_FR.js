window._lang = "fr_FR" ;
window._l10s = window._l10s || { } ;
window._l10s["fr_FR"] = {

  "#{0} from now": "dans #{0}",
  "#{0} ago": "il y a #{0}",
  "on #{0}": "le #{0}",
  "less than a minute": "moins d'une minute",
  "#{0} minute": "#{0} minute",
  "#{0} minutes": "#{0} minutes",
  "about one hour": "environ une heure",
  "#{0} hours": "#{0} heures",
  "one day": "un jour",
  "about one day": "environ un jour",
  "#{0} days": "#{0} jours"

} ;




